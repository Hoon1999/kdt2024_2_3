/**
 * 
 */
/**
 * 
 */
open module cafeServer {
	requires org.json;
	requires java.sql;
}