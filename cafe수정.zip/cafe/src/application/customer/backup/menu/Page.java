package application.customer.menu;

public enum Page {
    ORDER_PAGE,
    PAYMENT_PAGE,
    MAIN_PAGE;

    private Page() {
    }
}
